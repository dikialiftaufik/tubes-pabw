<?php

namespace Database\Seeders;

use App\Models\User;
// use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        $this->call([
            UserSeeder::class,
            MenuSeeder::class,
            ReservationSeeder::class,
            PesananSeeder::class,
            DetailPesananSeeder::class,
            NotificationSeeder::class,
            FeedbackSeeder::class,
            UserSeeder::class,
           
        ]);
    }
}
